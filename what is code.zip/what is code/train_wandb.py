import wandb
from dataLoader import DetailDetectionModel, joint_training
from ultralytics_copy import YOLO
from val import BGD_YOLO

if __name__ == "__main__":
    # --- 1. 统一配置超参数 ---
    hyp_params = {
        # 数据集与路径
        "data": "/home/bme-2020/czy/yolov10/data.yaml",
        "yolo_weight": "/home/bme-2020/czy/BGD-Yolo/runs/yolo/train10/weights/best.pt",
        "detail_weight": "run/detail_net_atten/relu_changed_channel=32_16.pt",

        # 训练超参数
        "lr0": 0.001,
        "batch": 32,
        "imgsz": 640,
        "epochs": 70,
        "workers": 4,  # 建议 Linux 设置为 4 或更高，提高读取效率

        # BGD 模型特定参数
        "target_layers": [-1],
        "detail_mode": True,
        "detail_conf_threshold": 0.1,
        "head_select": "low",
        "model_weight_only_yolo": True,

        # 项目管理
        "project_path": "yolo-runs/train",
        "experiment_name": "low_BGD_(detail:relu_changed_channel=32_16)"  # 对应你的 exp3_3_1 注释
    }

    # --- 2. 初始化 wandb ---
    wandb.init(
        project="BGD-YOLO",
        name=hyp_params["experiment_name"],
        config=hyp_params,
        notes="detail model channel压缩后32_16的结果"
    )


     # --- 3. 初始化模型 (BGD_YOLO) ---
    yolo_model = BGD_YOLO(
            model=hyp_params["yolo_weight"],
            model_weight_only_yolo=hyp_params["model_weight_only_yolo"],
            detail_weight=hyp_params["detail_weight"],
            target_layers=hyp_params["target_layers"],
            detail_mode=hyp_params["detail_mode"],
            conf_threshold=hyp_params["detail_conf_threshold"],
            head_select=hyp_params["head_select"]
        )

        # --- 4. 运行训练 ---
        # 使用 **hyp_params 将字典内容解包传参（可选），这里手动传参更清晰
    yolo_model.train(
            data=hyp_params["data"],
            lr0=hyp_params["lr0"],
            batch=hyp_params["batch"],
            imgsz=hyp_params["imgsz"],
            epochs=hyp_params["epochs"],
            workers=hyp_params["workers"],
            project=hyp_params["project_path"],
            name=hyp_params["experiment_name"]
        )

    # --- 5. (备选) 如果需要运行 bgd_val 逻辑，可以参考下述写法 ---
    """
    # 如果要跑验证，修改 model_weight_only_yolo=False 即可
    yolo_model.val(
        data=hyp_params["data"],
        split='test',
        imgsz=hyp_params["imgsz"],
        batch=1,
        conf=0.5
    )
    """

        # --- 6. 结束 wandb 任务 ---
    
    wandb.finish()
