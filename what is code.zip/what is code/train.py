from dataLoader import DetailDetectionModel,joint_training
from ultralytics_copy import YOLO
from val import BGD_YOLO

if __name__ == "__main__":
    #
    # 训练v8
    #
    # yolo_model = YOLO()
    # yolo_model.train(data="/home/bme-2020/czy/yolov10/data.yaml", batch=1, imgsz=640,epochs=300)

    # # val
    #  yolo_model = YOLO('/home/bme-2020/czy/BGD-Yolo/runs/yolo/train/weights/best.pt',)
    #  yolo_model.val(data="/home/bme-2020/czy/yolov10/data.yaml", split='test', imgsz=640, workers=1, batch=1)
    #

    #训练v8

    # yolo_model = BGD_YOLO('/home/bme-2020/czy/BGD-Yolo/runs/yolo/train/weights/best.pt',model_weight_only_yolo=True,detail_weight=None,target_layers=[-1],
    #                           detail_mode=True)
    # yolo_model.train(data="/home/bme-2020/czy/yolov10/data.yaml", batch=32, imgsz=640, epochs=300,
    #                project='yolo-runs/train')


    # bgd_val
   yolo_model = BGD_YOLO('yolo-runs/train/low_BGD_(detail:relu_changed_channel=32_16)2/weights/best.pt',
                         model_weight_only_yolo=False,
                         head_select='low',
                         target_layers=[-1],
                         detail_mode=True,
                         conf_threshold=0.1)
   yolo_model.val(data="/home/bme-2020/czy/yolov10/data.yaml", split='test',imgsz=640, workers=1,batch=1,conf=0.5)


    # bgd_train
    # exp3_3_1.pt detail_model_atten 原模型 (after correcting relu)
    # yolo_model = BGD_YOLO('/home/bme-2020/czy/BGD-Yolo/runs/yolo/train8/weights/best.pt',
    #                       model_weight_only_yolo=True,
    #                 detail_weight='run/detail_net_atten/exp3_3_1.pt',
    #                 target_layers=[-1],
    #                 detail_mode=True,
    #                 conf_threshold=0.2,
    #                 head_select='low')
    #
    # yolo_model.train(data="/home/bme-2020/czy/yolov10/data.yaml",
    #                  lr0=0.00001, batch=32, imgsz=640,epochs=60,
    #                  project='yolo-runs/train')
    #

